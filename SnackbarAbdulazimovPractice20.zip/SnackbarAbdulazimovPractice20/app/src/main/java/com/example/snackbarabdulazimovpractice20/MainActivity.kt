package com.example.snackbarabdulazimovpractice20

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v4.view.accessibility.AccessibilityEventCompat.setAction
import android.view.View
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onClick(view: View) {
        var snackbar = Snackbar.make(view, "Вы нажали на кнопку", Snackbar.LENGTH_LONG)

        snackbar.setAction("Далее...", View.OnClickListener() {
            Toast.makeText(this, "Дополнительная кнопка нажата", Toast.LENGTH_SHORT).show()
        })

        snackbar.setActionTextColor(Color.RED)

        snackbar.show();
    }
}